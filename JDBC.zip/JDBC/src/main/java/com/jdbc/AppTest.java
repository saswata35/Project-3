package com.jdbc;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class AppTest 
{
	public static void main(String[] args) {
		//System.out.println(DatabaseConnection.getDbConnection());
	    //regular expression
		Pattern p=Pattern.compile("..s");//.(dot) represent single character
		//Matcher m=p.matcher("zht");
		Matcher m=p.matcher("zhs");
		boolean b1=m.matches();
		
		boolean b2=Pattern.compile(".a").matcher("ea").matches();
		Pattern.matches("..s","khs");
		boolean b3=Pattern.matches("[abc]","b");
		//boolean b3=Pattern.matches("[^abc]",/*"k"*/ "b");
		//boolean b3=Pattern.matches("[a-z]",/*"b"*//*"*"*/ /*"S"*/"12");
		//boolean b3=Pattern.matches("[a-zA-Z]","S");
		//boolean b4=Pattern.matches("[a-zA-Z]*",/*"b"*/"Shawin");
		boolean b4=Pattern.matches("[a-zA-Z @]{1}",/*"b"*/"Shawin Pradhan");
		//meta character - /d = [0-9] /D = ![0-9] /s - white space char /S - No White Space Char
		// /w = [a-zA-Z_0-9]
		
		
		//create a pattern to accept valid email address
		
		System.out.println(b1+" "+b2+" "+b3+" "/*b3*/+b4);
	}
}
