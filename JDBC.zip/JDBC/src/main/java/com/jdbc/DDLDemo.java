package com.jdbc;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class DDLDemo {

	public static void main(String[] args) {
     try(Connection con=DatabaseConnection.getDbConnection())
     {
    	 Statement st=con.createStatement();
    	 //write the query
    	 String createQuery="CREATE TABLE USER(id INT PRIMARY KEY,name VARCHAR(30),email VARCHAR(50))";
    	 //execute the query
    	 st.executeUpdate(createQuery);
    	 System.out.println("Table created successfully!");
    	 String alterQuery="ALTER TABLE user ADD COLUMN email varchar(50)";
    	 st.executeUpdate(alterQuery);
    	 System.out.println("Table altered successfully!");
    	 String dropQuery="DROP TABLE user";
    	 st.executeUpdate(dropQuery);
    	 System.out.println("Table dropped successfully!");
    	 st.close();
     }
     catch(SQLException e) {
    	 System.out.println(e.getMessage());
     }

	}

}
