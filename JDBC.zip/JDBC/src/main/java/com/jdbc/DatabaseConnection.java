package com.jdbc;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import com.mysql.cj.jdbc.Driver;
public class DatabaseConnection {
	static Connection con=null;
	//this method will create connection and return connection object
    public static Connection getDbConnection() {
    	try {
    		//register the driver
    		//Class.forName("com.mysql.cj.jdbc.Driver");
    		//OR
    		//Driver driver=new Driver();
    		//DriveManager.registerDriver(driver);
			//DriverManager.getConnection(null,null,null);
			String url="jdbc:mysql://localhost:3306/StudentManagementSystem";
			String userName="root";
			String password="root";
			//establish a connection
			con=DriverManager.getConnection(url,userName,password);
		} catch (SQLException e) {
			e.printStackTrace();
		}
	    return con;
}
}