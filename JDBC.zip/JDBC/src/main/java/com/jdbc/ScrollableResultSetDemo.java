package com.jdbc;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
public class ScrollableResultSetDemo {

	public static void main(String[] args) {
		try(Connection con=DatabaseConnection.getDbConnection()){
			//create the statement object
			Statement st=con.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE,ResultSet.CONCUR_READ_ONLY);
			String query="SELECT StudentId,FirstName,LastName,dateOfBirth from student";
			ResultSet rs=st.executeQuery(query);
			//Moves the cursor to the last row
			rs.last();
			System.out.println("Last Record:");
			System.out.println("Student Id:"+rs.getString("StudentId"));
			System.out.println("First Name:"+rs.getString("FirstName"));
			System.out.println("Last Name:"+rs.getString("LastName"));
			System.out.println("DOB:"+rs.getDate("dateOfBirth"));
			rs.first();//moves the cursor to first row
			System.out.println("Last Record:");
			System.out.println("Student Id:"+rs.getString("StudentId"));
			System.out.println("First Name:"+rs.getString("FirstName"));
			System.out.println("Last Name:"+rs.getString("LastName"));
			System.out.println("DOB:"+rs.getDate("dateOfBirth"));
			rs.absolute(2);//moves the cursor to the absolute position(2nd row)
	    	System.out.println("Student Id:"+rs.getString("StudentId"));
			System.out.println("First Name:"+rs.getString("FirstName"));
			System.out.println("Last Name:"+rs.getString("LastName"));
			System.out.println("DOB:"+rs.getDate("dateOfBirth"));
			//close the statement
			st.close();
	    	
	    } catch (SQLException e) {
			System.out.println(e.getMessage());
		}

}
}
