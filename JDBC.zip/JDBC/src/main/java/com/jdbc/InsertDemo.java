package com.jdbc;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.util.Scanner;
import java.util.regex.Pattern;

public class InsertDemo {

	public static void main(String[] args) {
     try(Connection con=DatabaseConnection.getDbConnection();
    		 Scanner sc=new Scanner(System.in))
     {
    	 Statement st=con.createStatement();
    	 System.out.println("Enter student Id:");
   
    	 String studentId=sc.next();
    	 sc.nextLine();
    	 System.out.println("Enter first name:");
    	 String first=sc.nextLine();
    	 System.out.println("Enter last name:");
    	 String last=sc.nextLine();
    	 System.out.println("Enter DOB:");
    	 String dob=sc.next();
    	 LocalDate date=LocalDate.parse(dob);
    	 System.out.println("Enter gender:");
    	 String gender=sc.next();
    	 System.out.println("Enter email:");
    	 String email=sc.next();
    	 System.out.println("Enter phone number:");
    	 String phone=sc.next();

    	 boolean flag=Pattern.matches("[6789]{1}[0-9]{9}", phone);
    	 if(flag) {String insertQuery="INSERT INTO student(StudentId,FirstName,LastName,DateOfBirth,Gender,Email,Phone)"+" VALUES('"+studentId+"','"+first+"','"+last+"','"+dob+"','"+gender+"','"+email+"','"+phone+"')";         
    	 int rowsAffected=st.executeUpdate(insertQuery);
    	 System.out.println(rowsAffected+"row(s) inserted successfully!");
    	 }
    	 else {
    		 System.out.println("Invalid Phone number!!");
    	 }
    	 st.close();
     }
     catch(SQLException e) {
    	 System.out.println(e.getMessage());
     }

	}

}
