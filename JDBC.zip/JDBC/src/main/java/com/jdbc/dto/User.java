package com.jdbc.dto;
//DTO

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

//DTO
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class User {

	//define the properties
	private int id;
	private String name;
	private String email;
}