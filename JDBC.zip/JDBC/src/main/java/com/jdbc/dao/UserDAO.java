//Package Name:-
package com.jdbc.dao;
import java.sql.SQLException;
//Importing List Class
import java.util.List;
import com.jdbc.dto.User;
//DAO
public interface UserDAO {
//method to add user details
	void addUser(User user);
	//method to get user details using id
	User getUserById(int id);
	//method to fetch all user details
	List<User> getAllUsers();
	//update user details using id
	void updateUser(int id,User user);
	//delete user details using id
	void deleteUserById(int id);
}
