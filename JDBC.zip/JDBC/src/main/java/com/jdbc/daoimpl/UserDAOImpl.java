//Package Name:-
package com.jdbc.daoimpl;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
//Importing ArrayList Class
import java.util.ArrayList;
//Importing List Class
import java.util.List;

import com.jdbc.DatabaseConnection;
import com.jdbc.dao.UserDAO;
import com.jdbc.dto.User;
//concreate DAO
public class UserDAOImpl implements UserDAO {
Connection con;
@Override
public void addUser(User user){
	//Try-Catch-Finally Block
	try {
		con=DatabaseConnection.getDbConnection();
		//If a connection is in auto-commit mode, then all its SQLstatements will be executed and committed as individualtransactions.
		con.setAutoCommit(false);//auto-commit false
		String insertUser="INSERT INTO USER(id,name,email) VALUES(?,?,?)";
		//An object that represents a precompiled SQL statement. 
		PreparedStatement ps=con.prepareStatement(insertUser);
		ps.setInt(1, user.getId());
		ps.setString(2,user.getName());
		ps.setString(3, user.getEmail());
		int rowsAffected=ps.executeUpdate();
		if(rowsAffected>0) {
			//Makes all changes made since the previouscommit/rollback permanent and releases any database lockscurrently held by this Connection object. 
			con.commit();//save the changes
			System.out.println(rowsAffected+"user added successfully!");
			
		}
		else {
			//Undoes all changes made in the current transactionand releases any database locks currently heldby this Connection object.
			con.rollback();//rollback to previous commit/rollback
			System.out.println("User details was not added.");
			
		}
	}
	catch(SQLException e) {
		//Try-Catch Block
		try {
			//Undoes all changes made in the current transactionand releases any database locks currently heldby this Connection object.
			
			con.rollback();
		}catch(SQLException e1) {
			e1.printStackTrace();
		}
		e.printStackTrace();
	}
	finally {
		//Try-Catch Block
		try {
			if(con!=null) {
				//Calling the method close on a Connectionobject that is already closed is a no-op. 
				con.close();
			}
		}
		catch(SQLException e) {
			e.printStackTrace();
		}
	}
}

@Override
public User getUserById(int id) {
	User user = null;
	//Try-Catch-Finally Block
	try
	{
		con = DatabaseConnection.getDbConnection();
		
		con.setAutoCommit(false); //auto-commit false
		
		String getUser = "SELECT * FROM user where id=?";
		
		PreparedStatement ps = con.prepareStatement(getUser);
		
		ps.setInt(1, id);
		
		ResultSet rs = ps.executeQuery();
		
		if(rs.next())
		{
			user = new User();
			
			user.setId(rs.getInt("id"));
			user.setName(rs.getString("name"));
			user.setEmail(rs.getString("email"));
		}
		else
		{
			System.out.println("User details not found!!");
		}
		//Makes all changes made since the previouscommit/rollback permanent and releases any database lockscurrently held by this Connection object. 
		con.commit();
		
		
	}
	catch(SQLException e)
	{
		try {
			//Undoes all changes made in the current transactionand releases any database locks currently heldby this Connection object.
			con.rollback();
		} catch (SQLException e1) {
			e1.printStackTrace();
		}
		e.printStackTrace();
	}
	finally
	{
		try {
			if(con!=null)
				//Calling the method close on a Connectionobject that is already closed is a no-op. 
				con.close(); //closing the connection
		}
		catch(SQLException e){
			e.printStackTrace();
		}
	}
	
	return user;
}
@Override
public List<User> getAllUsers(){
	User user = null;
	List<User> users = new ArrayList<>();
	
	try
	{
		con = DatabaseConnection.getDbConnection();
		//If a connection is in auto-commit mode, then all its SQLstatements will be executed and committed as individualtransactions.
		con.setAutoCommit(false); //auto-commit false
		
		Statement st = con.createStatement();
		
		String getAllUsers = "SELECT * FROM user";
		
		ResultSet rs = st.executeQuery(getAllUsers);
		
		while(rs.next())
		{
			user = new User();
			
			user.setId(rs.getInt("id"));
			user.setName(rs.getString("name"));
			user.setEmail(rs.getString("email"));
			users.add(user); //adding user details to the list
		}
		//Makes all changes made since the previouscommit/rollback permanent and releases any database lockscurrently held by this Connection object. 
		con.commit();	
		
	}
	catch(SQLException e)
	{
		try {
			//Undoes all changes made in the current transactionand releases any database locks currently heldby this Connection object.
			con.rollback();
		} catch (SQLException e1) {
			e1.printStackTrace();
		}
		e.printStackTrace();
	}
	finally
	{
		try {
			if(con!=null)
				//Calling the method close on a Connectionobject that is already closed is a no-op. 
				con.close(); //closing the connection
		}
		catch(SQLException e){
			e.printStackTrace();
		}
	}
	
	return users;
}
@Override
public void updateUser(int id, User user) {
	try {
		con = DatabaseConnection.getDbConnection();
		////If a connection is in auto-commit mode, then all its SQLstatements will be executed and committed as individualtransactions.
		con.setAutoCommit(false);

		String updateUser = "UPDATE user SET name=?, email=? WHERE id=?";
		PreparedStatement ps = con.prepareStatement(updateUser);

		ps.setString(1, user.getName());
		ps.setString(2, user.getEmail());
		ps.setInt(3, id);

		int rowsAffected = ps.executeUpdate();

		if (rowsAffected > 0) {
			//Makes all changes made since the previouscommit/rollback permanent and releases any database lockscurrently held by this Connection object. 
			con.commit();
			System.out.println(rowsAffected + " user updated successfully!");
		} else {
			//Undoes all changes made in the current transactionand releases any database locks currently heldby this Connection object.
			con.rollback();
			System.out.println("User details were not updated.");
		}
	} catch (SQLException e) {
		try {
			//Undoes all changes made in the current transactionand releases any database locks currently heldby this Connection object.
			con.rollback();
		} catch (SQLException e1) {
			e1.printStackTrace();
		}
		e.printStackTrace();
	} finally {
		try {
			if (con != null) {
				//Calling the method close on a Connectionobject that is already closed is a no-op. 
				con.close();
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
}

@Override
public void deleteUserById(int id) {
	try {
		con = DatabaseConnection.getDbConnection();
		//If a connection is in auto-commit mode, then all its SQLstatements will be executed and committed as individualtransactions.
		con.setAutoCommit(false);

		String deleteUser = "DELETE FROM user WHERE id=?";
		PreparedStatement ps = con.prepareStatement(deleteUser);

		ps.setInt(1, id);

		int rowsAffected = ps.executeUpdate();

		if (rowsAffected > 0) {
			//Makes all changes made since the previouscommit/rollback permanent and releases any database lockscurrently held by this Connection object. 
			con.commit();
			System.out.println(rowsAffected + " user deleted successfully!");
		} else {
			//Undoes all changes made in the current transactionand releases any database locks currently heldby this Connection object.
			con.rollback();
			System.out.println("User with id " + id + " not found or deletion failed.");
		}
	} catch (SQLException e) {
		try {
			//Undoes all changes made in the current transactionand releases any database locks currently heldby this Connection object.
			con.rollback();
		} catch (SQLException e1) {
			e1.printStackTrace();
		}
		e.printStackTrace();
	} finally {
		try {
			if (con != null) {
				//Calling the method close on a Connectionobject that is already closed is a no-op. 
				con.close();
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
}

}