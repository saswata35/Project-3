/*Question-1:-
 Lab Assignment 1: Understanding Basic JDBC Concepts
Task:
Create a Java program that establishes a connection to a MySQL database using
JDBC.
Execute a simple SQL query to retrieve and print data from student table.
 */
//Input:-

//Package Name:-
package com.jdbc;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
//File Name:-
public class SelectQueryEx {

	public static void main(String[] args) {
    try(Connection con=DatabaseConnection.getDbConnection()){
    	Statement st=con.createStatement();
    	String query="SELECT * FROM Student";
    	//executing the query
    	ResultSet rs=st.executeQuery(query);
    	while(rs.next()) {
    		System.out.println("Id:"+rs.getString("StudentId"));
    		System.out.println("First Name:"+rs.getString("FirstName"));
    		System.out.println("Last Name:"+rs.getString("LastName"));
    		System.out.println("DateOfBirth:"+rs.getDate(4));
    		System.out.println("Gender:"+rs.getString("Gender"));
    		System.out.println("Email:"+rs.getString("Email"));
    		System.out.println("Phone No:"+rs.getString("Phone"));
    		System.out.println("===========");
    	}
    	st.close();
    } catch (SQLException e) {
		e.printStackTrace();
	}

	}

}
//Output:-
/*
Id:S101
First Name:Saswata
Last Name:Banerjee
DateOfBirth:2001-12-20
Gender:M
Email:sasban@gmail.com
Phone No:7439593227
===========
Id:S102
First Name:Navanil
Last Name:Ghosh
DateOfBirth:2000-10-10
Gender:M
Email:navanilghosh@gmail.com
Phone No:4784679134
===========
Id:S103
First Name:Arka
Last Name:Dutta
DateOfBirth:2013-08-08
Gender:F
Email:arkadutta@gmail.com
Phone No:7614579536
===========
Id:S104
First Name:Avijit
Last Name:Ghosh
DateOfBirth:2011-09-08
Gender:F
Email:avijitghosh@gmail.com
Phone No:6475624879
===========
Id:S105
First Name:Manas
Last Name:Manna
DateOfBirth:2011-06-05
Gender:M
Email:manasmanna@gamil.com
Phone No:7614587654
===========
Id:S106
First Name:Rohit
Last Name:Dey
DateOfBirth:2003-01-07
Gender:M
Email:rohit@gmail.com
Phone No:7469757689
===========
Id:S107
First Name:Susmita
Last Name:Das
DateOfBirth:2004-11-20
Gender:F
Email:susmitadas@gmail.com
Phone No:4759865789
===========
Id:S202
First Name:Rohit
Last Name:Dey
DateOfBirth:2001-03-03
Gender:M
Email:@gmail.com
Phone No:9456789346
===========
*/