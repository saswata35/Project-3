/*Question:-
Assignment 2. Implement User DAO
Task 1: Create a Users Table
Create a database table named Users with fields like id, name, email.
Task 2: Implement User DAO
Create a User class representing a user with attributes like id, name, email.
Create a UserDao interface defining CRUD operations for users (add, get, update, delete).
Implement the UserDao interface using JDBC in a class named UserDaoImpl.
Task 3: Test User DAO Implementation
Write a Java program to test the UserDao implementation.
Perform operations like adding new users, retrieving users details, updating users
information, and deleting users.
Display the results to ensure the operations are executed correctly.
Note:
Ensure to handle exceptions properly in your code and close the resources (connections,
statements, result sets) after usage to prevent resource leaks. Test your programs with
various scenarios to validate the correctness of your implementations.
*/
//Package Name:-
package com.jdbc;
//Importing List Class
import java.util.List;
//Importing Scanner Class
import java.util.Scanner;
import com.jdbc.dao.UserDAO;
import com.jdbc.daoimpl.UserDAOImpl;
import com.jdbc.dto.User;
//File Class
public class Main {
	public static void main(String[] args) {
		//Constructs a new Scanner that produces values scannedfrom the specified input stream.
		Scanner sc = new Scanner(System.in);
		UserDAO userDao = new UserDAOImpl();
		User user = null;
		int choice, id;
		//Do-While Loop
		do
		{
			System.out.println("1) Add a new user\n"
					+ "2) Get user details using id\n"
					+ "3) Get all users\n"
					+ "4) Update user\n"
					+ "5) Delete user by id\n"
					+ "6) Exit");
			System.out.println("Enter the choice:");
			choice = sc.nextInt();
			//Switch Case
			switch(choice)
			{
			case 1:
				//add user method 
				System.out.println("Enter id: ");
				id = sc.nextInt();
				sc.nextLine();
				System.out.println("Enter name: ");
				String name = sc.nextLine();
				System.out.println("Enter email: ");
				String email = sc.next();
				
				user = new User(id, name, email);
				userDao.addUser(user);
				System.out.println();
				break;
				
			case 2:
				System.out.println("Enter id: ");
				id = sc.nextInt();
				user = userDao.getUserById(id);
				System.out.println(user);
				System.out.println();
				break;
				
			case 3:
				List<User> users = userDao.getAllUsers();
				for(User u : users)
				{
					System.out.println(u);
				}
				System.out.println();
				break;
				
			case 4:
				System.out.println("Enter id to update: ");
                id = sc.nextInt();
                sc.nextLine();
                System.out.println("Enter new name: ");
                String newName = sc.nextLine();
                System.out.println("Enter new email: ");
                String newEmail = sc.next();

                User updatedUser = new User(id, newName, newEmail);
                userDao.updateUser(id, updatedUser);
                System.out.println();
                break;
				
			case 5:
				System.out.println("Enter id to delete: ");
                id = sc.nextInt();
                userDao.deleteUserById(id);
                System.out.println();
                break;
				
			case 6:
				System.out.println("Thank you for visiting!!");
				System.exit(0);
				break;
			}
		}
		while(true);
	}
}
//Output:-
/*
1) Add a new user
2) Get user details using id
3) Get all users
4) Update user
5) Delete user by id
6) Exit
Enter the choice:
1
Enter id: 
100
Enter name: 
Tiyasa
Enter email: 
tiyasa@gmail.com
1user added successfully!

1) Add a new user
2) Get user details using id
3) Get all users
4) Update user
5) Delete user by id
6) Exit
Enter the choice:
2
Enter id: 
105
User(id=105, name=Susmita, email=susmitadas@gmail.com)

1) Add a new user
2) Get user details using id
3) Get all users
4) Update user
5) Delete user by id
6) Exit
Enter the choice:
3
User(id=100, name=Tiyasa, email=tiyasa@gmail.com)
User(id=101, name=anik banerjee, email=anikbanerjee@gmail.com)
User(id=104, name=Rohit, email=rohitdey@gmail.com)
User(id=105, name=Susmita, email=susmitadas@gmail.com)
User(id=110, name=Navanil, email=navanilghosh@gmail.com)
User(id=111, name=Manas, email=manasmanna@gmail.com)
User(id=112, name=Avijit, email=avijitdas@gmail.com)
User(id=200, name=Soma, email=soma@gmail.com)
User(id=202, name=sonu, email=sonupradhan@gmail.com)
User(id=203, name=nilarghaya, email=nil@gmail.com)

1) Add a new user
2) Get user details using id
3) Get all users
4) Update user
5) Delete user by id
6) Exit
Enter the choice:
4
Enter id to update: 
202
Enter new name: 
Jayanta
Enter new email: 
jayantabanerjee@gmail.com
1 user updated successfully!

1) Add a new user
2) Get user details using id
3) Get all users
4) Update user
5) Delete user by id
6) Exit
Enter the choice:
5
Enter id to delete: 
203
1 user deleted successfully!

1) Add a new user
2) Get user details using id
3) Get all users
4) Update user
5) Delete user by id
6) Exit
Enter the choice:
6
Thank you for visiting!!
*/