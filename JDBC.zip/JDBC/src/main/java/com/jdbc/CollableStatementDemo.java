package com.jdbc;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

public class CollableStatementDemo {

	public static void main(String[] args) {
		try(Connection con=DatabaseConnection.getDbConnection();
	    		 Scanner sc=new Scanner(System.in))
	     {
             String callProcedure="{CALL getStudentDetails(?)}";
             //create callable statement object
             CallableStatement cal=con.prepareCall(callProcedure);
             System.out.println("Enter StudentId:");
             String stdId=sc.next();
             //setter method to set the value of the procedure statement
             cal.setString(1, stdId);
             //executing the query
             ResultSet rs=cal.executeQuery();
             if(rs.next()) {
            	 System.out.println("Student First Name:"+rs.getString("FirstName"));
            	 System.out.println("Student Last Name:"+rs.getString("LastName"));
            	 System.out.println("Student Email:"+rs.getString("Email"));
             }
             else {
            	 System.out.println("Student with id:"+stdId+"details not found!");
             }
	     }
	     catch(SQLException e) {
	    	 System.out.println(e.getMessage());
	     }


	}
}
