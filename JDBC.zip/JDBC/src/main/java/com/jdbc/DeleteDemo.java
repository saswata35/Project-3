package com.jdbc;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;

public class DeleteDemo {

	public static void main(String[] args) {
	     try(Connection con=DatabaseConnection.getDbConnection())
	     {
	    	 Statement st=con.createStatement();
	         st.close();
	     }
	     catch(SQLException e) {
	    	 System.out.println(e.getMessage());
	     }


	}

}
