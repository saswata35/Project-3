package com.jdbc;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;
public class InsertUsingPS {

	public static void main(String[] args) {
		try(Connection con=DatabaseConnection.getDbConnection();
	    		 Scanner sc=new Scanner(System.in))
	     {
            String query="INSERT INTO USER(id,name,email) VALUES(?,?,?)";
            //creating an object of prepared statement by passing the
            //query in the prepareStatement method called from connection object
            PreparedStatement ps=con.prepareStatement(query);
	    	 System.out.println("Enter user Id:");
	    	 int id=sc.nextInt();
	    	 sc.nextLine();
	    	 System.out.println("Enter user name:");
	    	 String user=sc.nextLine();
	    	 System.out.println("Enter email:");
	    	 String email=sc.next();
	    	 //set the parameter values for the prepared statement
	    	 //setter methods two parameters-int paramIndex,value
	    	 ps.setInt(1, id);
	    	 ps.setString(3, email);
	    	 ps.setString(2, user);
	    	 //execute the prepared statement
	    	 int rowsAffected=ps.executeUpdate();
	    	 if(rowsAffected>0) {
	    		 System.out.println(rowsAffected+"row inserted successfully!");
	    	 }
	    	 else {
	    		 System.out.println("Insert query failed!");
	    	 }
	     }
	     catch(SQLException e) {
	    	 System.out.println(e.getMessage());
	     }

		}


}
