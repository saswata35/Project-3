package com.jdbc;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;
public class CreateQueryDemo {

	public static void main(String[] args) {
		//getting the connection object
		try(Connection con=DatabaseConnection.getDbConnection())//try-with-resource
		{
			//create statement object
			Statement st=con.createStatement();//may throw an SQLException
			//write the query
			//String createQuery="CREATE TABLE USER(id INT PRIMARY KEY,name VARCHAR(30))";
			//execute the query
			//st.executeUpdate(createQuery);
			//System.out.println("Table created successfully!");
			//write the insert query
			String insertQuery=" INSERT INTO USER VALUES(110,'Navanil','navanilghosh@gmail.com'),(111,'Manas','manasmanna@gmail.com'),(112,'Avijit','avijitdas@gmail.com');";
			int rowsAffected=st.executeUpdate(insertQuery);
			System.out.println(rowsAffected+"row(s) inserted successfully!");
			//closing the statement
			st.close();
		}
		catch(SQLException e) {
			e.printStackTrace();
		}

	}

}
