//Question-2:-
/*
 Task:
Create a Java program that uses JDBC to perform advanced DDL operations.
Create a new table with primary keys and foreign keys.
Alter the table structure (add columns, modify data types, etc.).
Implement DML operations to:
Insert data into the table.
Update existing records.
Delete records based on specific conditions.
 */
//Input:-
//Package Name:-
package com.jdbc1;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
//File Name:-
public class JdbcAdvancedOperations {

    public static void main(String[] args) {
        // JDBC URL, username, and password of MySQL server
        String url = "jdbc:mysql://localhost:3306/StudentManagementSystem";
        String user = "root";
        String password = "root";
        //Try-Catch Block
        try {
            // Establish a connection
            Connection connection = DriverManager.getConnection(url, user, password);

            // Create a statement
            Statement statement = connection.createStatement();

            // DDL Operations

            // Create a new table named "Course" with primary keys and foreign keys
            String createTableQuery = "CREATE TABLE Course3 (" +
                    "CourseID INT PRIMARY KEY, " +
                    "CourseTitle VARCHAR(255), " +
                    "Credits INT, " +
                    "Course_description VARCHAR(255)" +
                    ")";
            statement.executeUpdate(createTableQuery);

            // Alter the table structure (add a new column)
            String alterTableQuery = "ALTER TABLE Course3 ADD COLUMN Department VARCHAR(50)";
            statement.executeUpdate(alterTableQuery);

            // DML Operations

            // Insert data into the table
            String insertDataQuery = "INSERT INTO Course3 (CourseID, CourseTitle, Credits, Course_description, Department) " +
                    "VALUES (1, 'Introduction to Java', 3, 'Learn the basics of Java programming', 'Computer Science')";
            statement.executeUpdate(insertDataQuery);

            // Update existing records
            String updateDataQuery = "UPDATE Course3 SET Credits = 4 WHERE CourseID = 1";
            statement.executeUpdate(updateDataQuery);

            // Delete records based on specific conditions
            String deleteDataQuery = "DELETE FROM Course3 WHERE Credits < 3";
            statement.executeUpdate(deleteDataQuery);

            // Close the resources
            statement.close();
            connection.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
//Output:-
/*
 * +----------+----------------------+---------+--------------------------------------+------------------+
| CourseID | CourseTitle          | Credits | Course_description                   | Department       |
+----------+----------------------+---------+--------------------------------------+------------------+
|        1 | Introduction to Java |       4 | Learn the basics of Java programming | Computer Science |
+----------+----------------------+---------+--------------------------------------+------------------+
1 row in set (0.02 sec)
*/
